java -jar smali/smali/build/libs/smali.jar a -a 34 classes -o framework/classes.dex
java -jar smali/smali/build/libs/smali.jar a -a 34 classes2 -o framework/classes2.dex
java -jar smali/smali/build/libs/smali.jar a -a 34 classes3 -o framework/classes3.dex